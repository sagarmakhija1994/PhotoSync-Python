# app/routers/auth.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.database import SessionLocal
from app.models import User, Device
from app.security import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["auth"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/register")
def register(
    username: str,
    email: str,
    password: str,
    device_name: str,
    db: Session = Depends(get_db),
):
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(status_code=400, detail="Username already exists")

    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=400, detail="Email already exists")

    user = User(
        username=username,
        email=email,
        password_hash=hash_password(password),
        status="PENDING",
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return {
        "message": "Registration successful. Await admin approval."
    }


@router.post("/login")
def login(
    username: str,
    password: str,
    device_id: str,
    device_name: str,
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.username == username).first()

    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if user.status != "ACTIVE":
        raise HTTPException(
            status_code=403,
            detail=f"Account status: {user.status}",
        )

    device = (
        db.query(Device)
        .filter(
            Device.user_id == user.id,
            Device.device_id == device_id,
            Device.revoked.is_(False),
        )
        .first()
    )

    if not device:
        device = Device(
            user_id=user.id,
            device_id=device_id,
            device_name=device_name,
        )
        db.add(device)

    device.last_seen = datetime.utcnow()
    db.commit()

    token = create_access_token(
        {
            "sub": str(user.id),
            "username": user.username,
            "device_id": device_id,
        }
    )

    return {
        "access_token": token,
        "token_type": "bearer",
    }
